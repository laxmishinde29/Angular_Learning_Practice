export interface batches
{
    name : string,
    fees : number,
    duration : string
}