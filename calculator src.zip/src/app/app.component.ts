import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent 
{
  no1 : number 
  no2 : number
  no3 : number 
  no4 : number
  no5 : number 
  no6 : number
  no7 : number 
  no8 : number 
  ret : number
  ret2 : number
  ret3 : number
  ret4 : number
  print1 : string
  print2 : string 
  print3 : string 
  print4 : string

  constructor() 
  {
    this.no1 = 0;
    this.no2 = 0;
    this.no3 = 0;
    this.no4 = 0;
    this.no5 = 0;
    this.no6 = 0;
    this.no7 = 0;
    this.no8 = 0;
    this.ret = 0;
    this.ret2 = 0;
    this.ret3 = 0;
    this.ret4 = 0;
    this.print1 = '';
    this.print2 = '';
    this.print3 = '';
    this.print4 = '';
  }

  Add(value : string,value2 : string)  
  {
    this.no1 = parseInt(value);
    this.no2 = parseInt(value2);
    this.ret = this.no1 + this.no2
    this.print1 = "Addition of Two Numbers is : " + this.ret
  }

  Substract(value : string,value2 : string)  
  {
    this.no3 = parseInt(value);
    this.no4 = parseInt(value2);
    this.ret2 = this.no3 - this.no4;
    this.print2 = "Substraction of Two Numbers is : " + this.ret2
  }

  Multiplication(value : string,value2 : string)  
  {
    this.no5 = parseInt(value);
    this.no6 = parseInt(value2);
    this.ret3 = this.no5 * this.no6
    this.print3 = "Multiplication of Two Numbers is : " + this.ret3
  }
  
  Division(value : string,value2 : string)  
  {
    this.no7 = parseInt(value);
    this.no8 = parseInt(value2);
    this.ret4 = this.no7 / this.no8
    this.print4 = "Division of Two Numbers is : " + this.ret4
  }
}
